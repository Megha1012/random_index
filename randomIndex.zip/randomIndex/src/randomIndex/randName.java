package randomIndex;
import java.util.*;
public class randName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random rand=new Random();
		int result=rand.nextInt(48)+1;
		System.out.println(result);

	}

}
